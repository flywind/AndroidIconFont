package com.uxdpen.library.iconfont

import android.content.Context
import android.content.res.Resources
import android.graphics.Typeface
import android.util.Log

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.Hashtable

import com.uxdpen.library.iconfont.R;


/**
 * Created by Flywind on 2017/12/25.
 * http://www.uxdpen.com
 */
object IconFont {

    /* Root Directory. src/main/assets/fonts/ */
    private val ROOT = "fonts/"

    private val FILE_NAME = "iconfont.ttf"

    /* Icon font file name */
    private val FONT_ICON = ROOT + FILE_NAME

    /* Cache Font asset to avoid extra memory head */
    private val cache = Hashtable<String, Typeface>()


    /**
     * @param context context passed
     * *
     * @return returns TypeFace object from cache
     */
    /* Returns Iconfont TypeFace */
    fun getTypeface(context: Context): Typeface? {
        synchronized(cache) {
            if (!cache.containsKey(FONT_ICON)) {
                cache.put(FONT_ICON, processFontFromRaw(context))
            } else {
                Log.i(IconFont::class.java.simpleName, "Loading typeface from cache")
            }
            return cache[FONT_ICON]
        }
    }

    private fun processFontFromRaw(context: Context): Typeface? {
        var typeface: Typeface? = null
        var inputStream: InputStream? = null

        val outPath = context.cacheDir.toString() + "/tmp" + System.currentTimeMillis() + ".raw"

        try {
            inputStream = context.resources.openRawResource(R.raw.iconfont)
        } catch (ignored: Resources.NotFoundException) {
        }

        try {
            assert(inputStream != null)
            val buffer = ByteArray(inputStream!!.available())
            val stream = BufferedOutputStream(FileOutputStream(outPath))
            var num: Int
            num = inputStream.read(buffer)
            while (num > 0) {
                stream.write(buffer, 0, num)
                num = inputStream.read(buffer)
            }
            stream.close()
            typeface = Typeface.createFromFile(outPath)
            if (File(outPath).delete()) {
                Log.i(IconFont::class.java.simpleName, "Deleted " + outPath)
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return typeface
    }
}
