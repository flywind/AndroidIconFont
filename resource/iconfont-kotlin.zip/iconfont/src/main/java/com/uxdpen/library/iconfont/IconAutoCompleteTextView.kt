package com.uxdpen.library.iconfont

import android.content.Context
import android.util.AttributeSet

/**
 * Created by Flywind on 2017/12/27.
 * http://www.uxdpen.com
 */
class IconAutoCompleteTextView : android.support.v7.widget.AppCompatAutoCompleteTextView {

    /**
     * @param context context passed
     */
    constructor(context: Context) : super(context) {
        typeface = IconFont.getTypeface(context)
    }

    /**
     * @param context context passed
     * *
     * @param attrs attributes in xml
     */
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        typeface = IconFont.getTypeface(context)
    }

    /**
     * @param context context passed
     * *
     * @param attrs attributes in xml
     * *
     * @param defStyleAttr style attributes
     */
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        typeface = IconFont.getTypeface(context)
    }
}